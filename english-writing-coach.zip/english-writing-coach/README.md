# English Writing Coach

可携带的 Agent 技能包：根据英语题目，按高中英语 100/120/140 分档画像或 CET-4/CET-6 作文及格/高分画像写原创文章。技能说明和档位资料以中文编写，生成的作文为英文。

## 包内文件

- `SKILL.md`：可直接加载的技能入口与工作流程。
- `references/level-guide.md`：档位画像、评分参照、体裁与语料边界。
- `references/natural-student-style.md`：自然学生语体与避免模板腔的写作指引。
- `references/detector-notes.md`：IWrite 数据的解读边界。
- `agents/openai.yaml`：可选的 OpenAI/Codex 界面元数据。

## 导入其他 Agent

将整个 `english-writing-coach` 文件夹放进目标 Agent 支持的技能目录，并保留 `references` 子目录。Agent 若支持通过技能名调用，可调用 `english-writing-coach`；否则将 `SKILL.md` 作为指令加载，并确保它能读取两个 reference 文件。若平台只接受单文件指令，将 `SKILL.md` 和两个 reference 合并进平台系统提示词或知识文件。具体目录和命令因平台而异；本包不依赖特定模型、API、MCP 工具或脚本。

示例：按 CET-6 高分档写一篇作文，题目：…… 要求：180–200 词，分三段，举一个日常生活中的具体例子。
